from app import create_app

application = create_app()

if __name__ == '__main__':
    application.run(port=int(application.config.get('FLASK_RUN_PORT', 5000)), debug=application.config.get('FLASK_DEBUG', True), host='localhost')
